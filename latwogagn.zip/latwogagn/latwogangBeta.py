import tkinter as tk
import random as r
import json
import os

SAVE_FILE = "money.json"

root = tk.Tk()
root.title("STREAM SIM BURST")
root.geometry("800x400")
root.configure(bg="black")

# ---------------- LOAD ----------------

def load_money():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, "r") as f:
                data = json.load(f)
                return int(data.get("money", 0))
        except:
            return 0
    return 0

def save_money():
    try:
        with open(SAVE_FILE, "w") as f:
            json.dump({"money": int(money)}, f)
    except:
        pass

money = load_money()
target = money

# ---------------- CANVAS ----------------

spam_canvas = tk.Canvas(root, width=300, height=400, bg="black", highlightthickness=0)
spam_canvas.place(x=0, y=0)

donate_canvas = tk.Canvas(root, width=300, height=150, bg="black", highlightthickness=0)
donate_canvas.place(x=500, y=250)

label = tk.Label(root, text="000 000 000", font=("Consolas", 28), fg="white", bg="black")
label.place(x=320, y=150)

# ---------------- DATA ----------------

spam_msgs = []
donate_msgs = []

names = [
    "XTB", "Tymbark", "Ewelina Kosmetyczna", "Allegro", "Bedoes 215",
    "VAR", "ZEN.COM", "Komputronik", "Bank Spółdzielczy", "Dawid Jasper"
]

spam_texts = [
    "OMG", "BROOO", "WTF", "EZ", "INSANE",
    "LOL", "NO WAY", "CRAZY", "SKIBIDI", "WHAT"
]

def format_money(x):
    return f"{int(x):09,}".replace(",", " ")

# ---------------- SPAM BURST ----------------

burst_count = 0
cooldown = False

def add_spam():
    item = spam_canvas.create_text(5, 380,
                                   anchor="w",
                                   text=r.choice(spam_texts),
                                   fill="white",
                                   font=("Consolas", 10))
    spam_msgs.append([item, 380])

def spam_loop():
    global burst_count, cooldown

    if not cooldown:
        if burst_count < 10:
            add_spam()
            burst_count += 1
        else:
            cooldown = True
            burst_count = 0
            root.after(2000, reset_cooldown)

    root.after(120, spam_loop)

def reset_cooldown():
    global cooldown
    cooldown = False

def animate_spam():
    remove = []

    for msg in spam_msgs:
        msg[1] -= 2.5
        spam_canvas.move(msg[0], 0, -2.5)

        if msg[1] < -20:
            spam_canvas.delete(msg[0])
            remove.append(msg)

    for msg in remove:
        spam_msgs.remove(msg)

    root.after(16, animate_spam)

# ---------------- DONATE ----------------

def add_donate(name, amount):
    if len(donate_msgs) >= 6:
        old = donate_msgs.pop(0)
        donate_canvas.delete(old[0])

    item = donate_canvas.create_text(5,
                                      140,
                                      anchor="w",
                                      text=f"{name}: {amount}",
                                      fill="lime",
                                      font=("Consolas", 11))

    donate_msgs.append([item, 140])

def animate_donate():
    for msg in donate_msgs:
        msg[1] -= 1.8
        donate_canvas.move(msg[0], 0, -1.8)

    root.after(16, animate_donate)

# ---------------- MONEY SYSTEM ----------------

def add_money():
    global target

    if r.random() < 0.02:
        add = r.randint(500, 2000)
    else:
        add = r.randint(1, 15)

    target += add

    if r.random() < 0.12:
        name = r.choice(names)
        gift = r.randint(50, 300)

        if r.random() < 0.02:
            gift = r.randint(1000, 5000)

        target += gift
        add_donate(name, gift)

    save_money()
    root.after(100, add_money)

def smooth():
    global money, target

    if money < target:
        diff = target - money
        money += max(1, diff // 8)

    label.config(text=format_money(money))
    root.after(10, smooth)

# ---------------- CLOSE SAVE ----------------

def on_close():
    save_money()
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_close)

# ---------------- START ----------------

spam_loop()
animate_spam()
animate_donate()
add_money()
smooth()

root.mainloop()